# [TΣΔM SLΔCҜβΩT]
# Square LINE.
# https://line.me/ti/g2/LMAIQCF1K0
# Saling Berbagi Ilmu
# Mastah Jangan Pelit
# Info lebih lanjut
# Add Me:(http://line.me/ti/p/%40ryp6149l)
# TUTORIAL INSTALL

# apt update
# apt upgrade
# apt install git
# apt install python3-pip
# pip3 install rsa
# pip3 install thrift==0.11.0
# pip3 install requests
# pip3 install bs4
# pip3 install gtts
# pip3 install pytz
# pip3 install humanfriendly
# pip3 install googletrans
# git clone https://github.com/TEAMSLACKBOT/selfbot.v1-py3

# Cara Run Bot
# Ketik -> cd selfbot.v1-py3
# Ketik -> python3 polos.py

# THANKS TO:
# sᴜᴘᴘᴏʀᴛᴇᴅ ʙʏ :
# TΣΔM SLΔCҜβΩT

# ADD LINE BY OWNER
# http://line.me/ti/p/%40ryp6149l
